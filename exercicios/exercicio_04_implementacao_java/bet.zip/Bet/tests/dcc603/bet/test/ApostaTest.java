/**
 * 
 */
package dcc603.bet.test;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;

import dcc603.bet.Aposta;

/**
 * @author Eduardo Figueiredo
 *
 * Atencao! Este caso de teste eh um esqueleto. 
 * Voce pode (e deve) mudar e ampliar sua implementacao.
 */
class ApostaTest {

	/*
	 * Template para a criacao de um caso de teste:
	 * 
	 * 		@Test
	 * 		public void test(){
	 * 			// dado que eu tenho...
	 * 			// quando eu faco...
	 * 			// entao eu epero que aconteca...
	 * 		}
	 */
	
	@Test
	void testProbabilidadePassa() {
		// dado que eu tenho...
		Aposta aposta = new Aposta(50);

		// quando eu faco...
		aposta.aumentarProbabilidade(10);

		// entao eu epero que aconteca...
		assertTrue("A probabilidade eh 60.", aposta.obterProbabilidade() == 60 );
	}

	@Test
	void testProbabilidadeFalha() {
		// dado que eu tenho...
		Aposta aposta = new Aposta(50);

		// quando eu faco...
		aposta.aumentarProbabilidade(10);

		// entao eu epero que aconteca...
		assertTrue("A probabilidade eh 60.", aposta.obterProbabilidadeErrada() == 60 );
	}
}
