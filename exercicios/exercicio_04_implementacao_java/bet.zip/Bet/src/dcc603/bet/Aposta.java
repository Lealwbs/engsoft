/**
 * 
 */
package dcc603.bet;

/**
 * @author Eduardo Figueiredo
 *
 * Atencao! Esta classe eh um esqueleto. 
 * Voce pode (e deve) mudar e ampliar a sua implementacao.
 */
public class Aposta {

	public static final int ABERTA = 1;
	public static final int FECHADA = 2;
	
	/**
	 * 
	 */
	protected int status = ABERTA;
	
	/**
	 * A probabilidade varia de 0 a 100
	 */
	protected int probabilidade = 0;
	
	/**
	 * 
	 */
	public Aposta(int prob) {
		this.probabilidade = prob;
	}

	/**
	 * @param incremento
	 */
	public void aumentarProbabilidade(int incremento) {
		this.probabilidade += incremento;
	}
	
	/**
	 * @return
	 */
	public int obterProbabilidade() {
		return this.probabilidade;
	}
	
	/**
	 * @return
	 */
	public int obterProbabilidadeErrada() {
		return this.status;
	}
}
